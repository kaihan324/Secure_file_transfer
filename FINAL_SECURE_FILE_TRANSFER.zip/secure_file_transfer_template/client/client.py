
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import socket
import json
from common import crypto_utils
import base64

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import dh, padding
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
HOST = '127.0.0.1'
PORT = 65453

PRIVATE_KEY_PEM = """
-----BEGIN RSA PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDJB52/BeDd7ETq
1vzbpN6c5iiyf0T263E7OcRmW3b8Ss1OV5gjMrmDv8hdOXBvq0Rhb34HOhZmE0ja
1Rqo7FTCHoczH1yzCoCP62753uvTV4GNZz8yKwBCjgv6KzT5eizZPNI+/uSO3Qdk
YhmsgN43jxwN0e/Mcc0Xy+L9efKWlUMhmAHhO9LG1GRbTVMgDl+NYtSfn/A8pEZl
13EFangjLMsDYCSMEnmeaZXspgOZc4s9N4U7jsdQ+3tWzDg2ixUJKGWLEqisX1YL
JUltrqtgXgArmJ7WVho4DCPCWvNCmnMnFYS89+pDGSQCz2xe3y88ITITKLnOfxis
CVsf1mQLAgMBAAECggEAOlrLn7fFHqaHGuRtYhTpygHFrorjKgoORHLwYAYM9A+C
qUskDpOa5nO1ZdpWmRPONbp3iwGBnv/aFivmIUL5F6Bk/qIL9q0FxMFC5aWgLykn
ojRmU9nHqYoyT9xa9FBS1HyjS0YScqYWjz0q1rhRyS7xpdFbGq2uK0o0CgBsOul1
S1mEzHl1QnzfxK0bsxHqyI/mU6L/UM2w7CZwld/hi9p1tS20LyTFAIgmMmePtxqX
YKDjD4y947mtR6pB2aArehw9X9njOhJ3Fz0lzB5LKIgBi65ncN82BOT4ZCERhrTh
xwCSGM2fIaRewKZAHPjn/iq5HjodccY5HHORW9IPAQKBgQDtfr1cqi3EZWMJ1/0J
Uafx8hRaNH8QmeCLhmUyAuynrRstfQTdQZjBAEPzW9JPrTraWRFfReTUFY1sfT18
65Gs8+JC2mFVoucnu/XPVeW3VfZcpx+MP3BQ4kq4SApGrcWzbAO5t+hCxd7ULYaN
DWu1FPvBpLXXtdQ5wy+93V95wwKBgQDYsYLMUf3igzee9a8EsLhGEIFOO6Kp+SSY
SpHwsAXJ2BZUwYUjKWm7j4tiej/5RQEphwZy0X61N6r58m6F2DA9vp3hShvcIl5U
EqCNj6fp1FH48dl89flJYywIh4lwZ/YB4qeGNfCLFBxg/XrQNAxHPssgpb04655z
ppSHvLaAGQKBgQDRzi0rN4vG/GpJv+1h1ikvrFQefFHkMIwVtlyfmcXHOz3PKaqq
a9Cub7WXv35DtR1Q125pZC2Kzp9pQBqZyOGgkLNJq/Jg3NCoYXv99jxBgkdqApn0
I/bs/XxU4A9z8P++SaXg437jvjnj53P+F+UWy7q8ju216oPZo30BlhdKUQKBgHUa
kR4MHVFBKljcWuYE/sDWgJqfvctvmeg3PGE/LxGilobdQi77XWmALIpemJ4EPZmM
n96C+p/CYsLK0hHBAGkNz1KF80JmzGVQ37VA8jR6ioYnZSqT31Fap9xAKvU1KYxh
SblNAx6WErQTqEBGMHB8LdgJ2ZWeN7Y2SsSEJnhZAoGBAM6yEoc9mdipxcVT7yHe
/+c+XfWFpzuU+ySUJCExO3ib/8Hs0TgDnVmTIssRUDnq8pe1d/SU4Bd0B1lsprcT
372L84eNflsTk0uDLeQNxpV6dTHv71d/7IraJk29zEi1qWeKIBTPyivhk0NJiv39
tfvuRUvUnXsA+NVr4D57Scrs
-----END RSA PRIVATE KEY-----

"""
PUBLIC_KEY_PEM = """
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyQedvwXg3exE6tb826Te
nOYosn9E9utxOznEZlt2/ErNTleYIzK5g7/IXTlwb6tEYW9+BzoWZhNI2tUaqOxU
wh6HMx9cswqAj+tu+d7r01eBjWc/MisAQo4L+is0+Xos2TzSPv7kjt0HZGIZrIDe
N48cDdHvzHHNF8vi/XnylpVDIZgB4TvSxtRkW01TIA5fjWLUn5/wPKRGZddxBWp4
IyzLA2AkjBJ5nmmV7KYDmXOLPTeFO47HUPt7Vsw4NosVCShlixKorF9WCyVJba6r
YF4AK5ie1lYaOAwjwlrzQppzJxWEvPfqQxkkAs9sXt8vPCEyEyi5zn8YrAlbH9Zk
CwIDAQAB
-----END PUBLIC KEY-----
"""
def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    try:
        print("Choose action:\n1) register\n2) login")
        choice = input("Enter choice (1/2): ").strip()
        if choice == "1":
            action = "register"
        elif choice == "2":
            action = "login"
        else:
            print("[!] Unknown command.")
            return

        username = input("Enter your username: ").strip()
        request_data = {
            "action": action,
            "username": username,
            "public_key": PUBLIC_KEY_PEM.strip()
        }
        client_socket.send(json.dumps(request_data).encode())
        response = client_socket.recv(1024).decode()
        print(f"[Server] {response}")
        if response not in ["User registered successfully.", "Login successful."]:
            return


        server_public_bytes = b""
        while True:
            chunk = client_socket.recv(4096)
            if not chunk:
                break
            server_public_bytes += chunk
            if b"-----END PUBLIC KEY-----" in server_public_bytes:
                break
        server_public_key = serialization.load_pem_public_key(server_public_bytes)

 
        parameters = server_public_key.parameters()
        client_private_key = parameters.generate_private_key()
        client_public_key = client_private_key.public_key()
        client_public_bytes = client_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        client_socket.sendall(client_public_bytes)
        print("[+] Sent client DH public key.")

   
        shared_key = client_private_key.exchange(server_public_key)
        symmetric_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b'handshake data'
        ).derive(shared_key)
        print("[+] Secure session established with DH-derived key.")

        while True:
            cmd = input("Enter command (upload_file/download_file/change_user_role/list_files/delete_file/exit): ").strip()
            if cmd == "exit":
                break

            if cmd == "upload_file":
                filename = input("Enter filename to upload: ").strip()
                if not os.path.isfile(filename):
                    print("[!] File not found.")
                    continue
                with open(filename, "rb") as f:
                    file_data = f.read()
                private_key = serialization.load_pem_private_key(PRIVATE_KEY_PEM.encode(), password=None)
                signature = private_key.sign(
                    file_data,
                    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                    hashes.SHA256()
                )
                request = {
                    "action": "upload_file",
                    "filename": os.path.basename(filename),
                    "file_data": base64.b64encode(file_data).decode(),
                    "signature": base64.b64encode(signature).decode()
                }

            elif cmd == "download_file":
                filename = input("Enter filename to download: ").strip()
                request = {"action": "download_file", "filename": filename}

            elif cmd == "change_user_role":
                target_user = input("Enter target username: ").strip()
                new_role = input("Enter new role (guest/maintainer/admin): ").strip()
                request = {"action": "change_user_role", "target_user": target_user, "new_role": new_role}

            elif cmd == "list_files":
                request = {"action": "list_files"}

            elif cmd == "delete_file":
                filename = input("Enter filename to delete: ").strip()
                request = {"action": "delete_file", "filename": filename}

            else:
                print("[!] Unknown command.")
                continue

            encrypted_request = crypto_utils.encrypt_message(symmetric_key, json.dumps(request))
            client_socket.send(encrypted_request)

            encrypted_response = client_socket.recv(8192)
            if not encrypted_response:
                print("[!] No response from server.")
                break
            response = crypto_utils.decrypt_message(symmetric_key, encrypted_response)

            if cmd == "download_file" and response.startswith("{"):
                response_data = json.loads(response)
                file_data = base64.b64decode(response_data["file_data"])
                signature = base64.b64decode(response_data["signature"])
                save_path = f"downloaded_{filename}"
                with open(save_path, "wb") as f:
                    f.write(file_data)
                with open(f"{save_path}.sig", "wb") as f:
                    f.write(signature)
                print(f"[+] File downloaded and saved as '{save_path}'")
         
                public_key = serialization.load_pem_public_key(PUBLIC_KEY_PEM.encode())
                try:
                    public_key.verify(
                        signature,
                        file_data,
                        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                        hashes.SHA256()
                    )
                    print("[+] Signature verified.")
                except Exception as e:
                    print("[!] Signature verification failed:", e)
            elif cmd == "list_files":
                file_list = json.loads(response).get("files", [])
                print("Files on server:", ", ".join(file_list) if file_list else "No files found.")
            else:
                print(f"[Server] {response}")

    finally:
        client_socket.close()
        print("[-] Connection closed.")


if __name__ == "__main__":
    start_client()